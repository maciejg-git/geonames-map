<template>
	<div>

	</div>
</template>

<script>
	export default {
		name: 'Component',
		components: {
		},
		data() {
			return {}
		},
		mounted: function() {},
		computed: {},
		methods: {}
	}
</script>

<style scoped>
</style>
