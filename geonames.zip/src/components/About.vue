<template>
	<div class="bg-light p-4">
		<h5>What is this?</h5>
This is free mapping application.
	</div>
</template>

<script>
	export default {
		name: 'About',
		data() {
			return {}
		},
	}
</script>

<style scoped>
</style>
