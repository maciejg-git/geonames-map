<template>
	<div>
		<div class="dropdown">
			<a href="" class="dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
				Actions
			</a>
			<div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
				<a @click.prevent="calculateDistance" class="dropdown-item" href="#">Calculate distances</a>
				<a class="dropdown-item" href="#">Another action</a>
				<a class="dropdown-item" href="#">Something else here</a>
			</div>
		</div>
	</div>
</template>

<script>
export default {
	name: 'HelloWorld',
	components: {
	},
	data() {
		return {
		}
	},
	mounted: function() {

	},
	computed: {

	},
	methods: {
		calculateDistance() {
			this.$emit("calculateDistance")
		}
	}
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
